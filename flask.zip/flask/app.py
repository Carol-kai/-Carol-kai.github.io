import re
from datetime import datetime
from flask import Flask, jsonify
from flask import render_template
from flask import url_for, request, redirect
from flask import flash
from email_validator import validate_email, EmailNotValidError
from flask import logging
from flask_debugtoolbar import DebugToolbarExtension
import os
from flask_mail import Mail, Message
import random
import string


from flask_login import LoginManager, login_required, current_user, UserMixin, login_user
from werkzeug.security import generate_password_hash, check_password_hash
 
import pymysql
 
app = Flask(__name__)
# 增加 secret_key
app.config["SECRET_KEY"]= "987654"
 
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
@login_manager.user_loader
class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password_hash = generate_password_hash(password)
 
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
   
@login_manager.user_loader
def load_user(user_id):
    with conn.cursor() as cursor04:
        sql = "SELECT * FROM register WHERE id = %s"
        cursor04.execute(sql, (user_id,))
        result = cursor04.fetchone()
        if result:
            return User(id=result[0], username=result[1], password=result[2])
        return None
 
   

 
 
conn = pymysql.connect(
 host="localhost", port=3306,
 user='root', passwd='',
 charset='utf8', db='pythondb'
)
with conn.cursor() as cursor01:
 sql01 = """
 create table if not exists student (
 prikey integer primary key auto_increment,
 name text,
 birthday text,
 sex text,
 phone text,
 address text
 )
"""
 # 執行 sql 指令
 cursor01.execute(sql01)
 # 送出執行
 conn.commit()
 # 新增記錄到資料庫裡
 sql02 = """
 insert into student values
 (null,'陳一','2001/01/01','1','089111','台東市中華路')
 """
 cursor01.execute(sql02)
 conn.commit()
 # 一次新增多筆記錄
 sql02 = """
 insert into student values
 (null,'王二','2002/02/02','0','089222','台東市中正路'),
 (null,'張三','2003/03/03','1','089333','台東市中山路'),
 (null,'李四','2004/04/04','0','089444','台東市中央路')
 """
 cursor01.execute(sql02)
 conn.commit()
 # 查詢資料表的記錄
 sql02 = "select * from student"
 cursor01.execute(sql02)
 rows01 = cursor01.fetchall()
 for row01 in rows01:
  print(row01)




 
 
 
# 除錯功能
# app.logger.setLevel(logging.DEBUG)
# 避免中斷重新導向
app.config["DEBUG_TB_INTERCEPT_REDIRECTS"] = False
# 在 DebugToolbarExtension 設置應用程式
toolbar = DebugToolbarExtension(app)
 
# 設定 mail 組態
app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 587
app.config["MAIL_USE_TLS"] = True
app.config["MAIL_USERNAME"] = "11012108@gm.nttu.edu.tw"
app.config["MAIL_PASSWORD"] = "vpifxoshviasjauh"
app.config["MAIL_DEFAULT_SENDER"] = "11012108@gm.nttu.edu.tw"
mail = Mail(app)
 
# 創建"註冊"資料表
with conn.cursor() as cursor04:
    sql_create_table = """
    CREATE TABLE IF NOT EXISTS register (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100),
 
        password VARCHAR(100),
        registration_time DATETIME
    )    """
    cursor04.execute(sql_create_table)
    conn.commit()


#"用戶問題"資料表
with conn.cursor() as cursor05:
    sql_create_table = """
    CREATE TABLE IF NOT EXISTS question (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    mail VARCHAR(100),
    content VARCHAR(100),
    registration_time DATETIME   
    ) """
    cursor05.execute(sql_create_table)
    conn.commit()


#"黑名單"資料表
with conn.cursor() as cursor06:
    sql_create_table = """
    CREATE TABLE IF NOT EXISTS blacklist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    password VARCHAR(100),
    violation VARCHAR(100)
   
    ) """
    cursor06.execute(sql_create_table)
    conn.commit()

#"支出"資料表
with conn.cursor() as cursor07:
    sql_create_table = """
    CREATE TABLE IF NOT EXISTS spend (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    name VARCHAR(100),
    category VARCHAR(255),
    date DATE ,
    money INT 
    ) """
    cursor07.execute(sql_create_table)
    conn.commit()

#"收入"資料表
with conn.cursor() as cursor08:
    sql_create_table = """
    CREATE TABLE IF NOT EXISTS revenu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    name VARCHAR(100),
    category VARCHAR(255),
    date DATE ,
    money INT 
    ) """
    cursor08.execute(sql_create_table)
    conn.commit()





# 插入資料
#with conn.cursor() as cursor03:
#    username = "ningning"
#    password = "1234"
#    registration_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#    sql_insert_data = """
#    INSERT INTO users (username, password, registration_time)
#    VALUES ('{}', '{}', '{}')
#    """.format(username, password, registration_time)
 #   cursor03.execute(sql_insert_data)
#    conn.commit()
 
# 查詢
#with conn.cursor() as cursor03:
#    sql_select_data = "SELECT * FROM users"
#    cursor03.execute(sql_select_data)
#    rows = cursor03.fetchall()
#   for row in rows:
#        print(row)
 
# 關閉連接
#conn.close()
 
 
 
@app.route("/")
def home():
   return render_template("home.html")
 
@app.route("/about/")
def about():
 
 
 
   return render_template("about.html")
 
@app.route("/contact/")
def contact():

            return render_template("contact.html" )

 

# 聯絡我們 送出資料後的動作，接收 GET 和 POST 的傳送方式
@app.route("/contact/complete", methods=["GET", "POST"])
def contact_complete():
    if request.method == "POST":
        # 接收表單傳來的內容
        username = request.form["username"]
        email = request.form["email"]
        content = request.form["content"]
        registration_time = datetime.now()

        # 加上檢測動作，flash 是作訊息傳遞使用的
        is_valid = True  # 預設正確
        if not username:
            flash("請填寫您的名字")
            is_valid = False
        try:
            validate_email(email)
        except EmailNotValidError:
            flash("請輸入正確的電子郵件格式")
            is_valid = False
        if not content:
            flash("請填寫內容")
            is_valid = False

        if not is_valid:
            return redirect(url_for("contact"))

        # 傳送郵件
        send_email(email, "感謝您的訊息", "contact_mail", username=username, content=content)

        # 保存數據到 question 資料表
        
        with conn.cursor() as cursor05:
            sql_insert_data = """
            INSERT INTO question (username, mail, content, registration_time)
            VALUES (%s, %s, %s, %s)
            """
            cursor05.execute(sql_insert_data, (username, email, content, registration_time))
            conn.commit()
        

        # 重新導向 contact 端點
        flash("內容已送出，感謝您的訊息！")
        return redirect(url_for("contact_complete"))

    return render_template("contact_complete.html")

def send_email(to, subject, template, **kwargs):
    msg = Message(subject, recipients=[to])
    msg.body = render_template(template + ".txt", **kwargs)
    msg.html = render_template(template + ".html", **kwargs)
    mail.send(msg)
 
 
 
#隨機驗證碼
def generate_captcha():
    captcha = ''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase + string.digits, k=6))
    return captcha
 
#"註冊"路由
@app.route("/register/", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        # 處理提交的表單
        username = request.form['username']
        password = request.form['password']
        user_captcha = request.form['userCaptcha']
        hidden_captcha = request.form['hiddenCaptcha']
        registration_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
 
        # 驗證
        if user_captcha != hidden_captcha:
            flash("驗證碼錯誤！")
            return redirect(request.url)
 
        # 傳至資料庫
        with conn.cursor() as cursor04:
            #資料表名稱
            sql_insert_data = """
            INSERT INTO register (username, password, registration_time)
            VALUES (%s, %s, %s)
            """
            cursor04.execute(sql_insert_data, (username, password, registration_time))
            conn.commit()
 
        flash("註冊成功！")
        return redirect(url_for('login'))
 
 
     #提交表單
    captcha = generate_captcha()
    return render_template("register.html", captcha=captcha)




 
 
 
#"登入"路由
@app.route("/login/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
       
        username = request.form['username']
        password = request.form['password']
        user_captcha = request.form['userCaptcha']
        hidden_captcha = request.form['hiddenCaptcha']
 
        # 驗證
        if user_captcha != hidden_captcha:
            flash("驗證碼錯誤！")
            return redirect(url_for('login'))
 
        # 進行資料驗證
        with conn.cursor() as cursor04:
            sql_check_user = "SELECT * FROM register WHERE username = %s AND password = %s"
            cursor04.execute(sql_check_user, (username, password))
            result = cursor04.fetchone()
            # 檢查是否為管理員
            if result:
                user = User(id=result[0], username=result[1], password=result[2])
 
                if username == 'admin':
                   
                    login_user(user)
                    flash("登入成功！")
                    return redirect(url_for('admin'))
                else:
                    login_user(user)
                    flash("登入成功！")
                    return redirect(url_for('user'))
            else:
                flash("帳號或密碼錯誤！")
 
    captcha = generate_captcha()
    return render_template("login.html", captcha=captcha)


 
@app.route("/admin/")
@login_required
def admin():
    if current_user.username == 'admin':
        with conn.cursor() as cursor04:
            # 查询
            sql = "SELECT * FROM register"
            cursor04.execute(sql)
            rows = cursor04.fetchall()
           
            cursor04.close()
        return render_template("admin.html", rows=rows)
    else:
        flash("您無權訪問管理端！")
        return redirect(url_for('user'))
 

@app.route("/user/")
@login_required
def user():
    requested_username = request.args.get('username')
    
    if not requested_username or requested_username == current_user.username:
        username = current_user.username
        with conn.cursor() as cursor07:
            # 擷取"支出"資料
            sql_select_spend = "SELECT id, name, category, date, money FROM spend WHERE username = %s"
            cursor07.execute(sql_select_spend, (username,))
            spend_rows = cursor07.fetchall()

            # 計算支出總金額
            sql_total_spend = "SELECT SUM(money) FROM spend WHERE username = %s"
            cursor07.execute(sql_total_spend, (username,))
            total_spend = cursor07.fetchone()[0] or 0

        with conn.cursor() as cursor08:
            # 擷取"收入"資料表
            sql_select_revenu = "SELECT id, name, category, date, money FROM revenu WHERE username = %s"
            cursor08.execute(sql_select_revenu, (username,))
            revenu_rows = cursor08.fetchall()

            # 計算收入總金額
            sql_total_revenu = "SELECT SUM(money) FROM revenu WHERE username = %s"
            cursor08.execute(sql_total_revenu, (username,))
            total_revenu = cursor08.fetchone()[0] or 0

            # 結餘
            balance = total_revenu - total_spend

        return render_template("user.html", username=username, spend_rows=spend_rows, revenu_rows=revenu_rows, total_spend=total_spend, total_revenu=total_revenu, balance=balance)
    else:
        return render_template("login.html", message="您只能查看自己的頁面", username=requested_username)





#黑名單 
@app.route("/admin/blacklist", methods=["GET", "POST"])
def blacklist():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        violation = request.form['violation']

        with conn.cursor() as cursor06:
            sql = "INSERT INTO blacklist (username, password, violation) VALUES (%s, %s, %s)"
            cursor06.execute(sql, (username, password, violation))
            conn.commit()

       
        return redirect(url_for('blacklist'))
        

    else:
        with conn.cursor() as cursor06:
            
            sql = "SELECT * FROM blacklist"
            cursor06.execute(sql)
            rows = cursor06.fetchall()

        
        return render_template("blacklist.html", rows=rows)


    
#用戶問題
@app.route("/admin/question")
def question():
        with conn.cursor() as cursor05:
            
            sql = "SELECT * FROM question"
            cursor05.execute(sql)
            rows = cursor05.fetchall()
           
            cursor05.close()
        return render_template("question.html", rows=rows)  





#支出
@app.route("/user/pay", methods=["GET", "POST"])
@login_required
def pay():
    if request.method == "POST":
        # 處理使用者提交的記帳資料
        name = request.form['name']
        category = request.form['category']
        date = request.form['date']
        money = request.form['money']

        # 將資料寫入資料庫，確保只有當前登入的使用者的資料被寫入
        with conn.cursor() as cursor07:
            sql_insert = "INSERT INTO spend (name, category, date, money, username) VALUES (%s, %s, %s, %s, %s)"
            cursor07.execute(sql_insert, (name, category, date, money, current_user.username))
            conn.commit()

        return redirect(url_for('pay'))
    else:
        # 讀取當前登入使用者的記帳紀錄
        with conn.cursor() as cursor07:
            sql_select = "SELECT * FROM spend WHERE username = %s"
            cursor07.execute(sql_select, (current_user.username,))
            rows = cursor07.fetchall()


        return render_template("pay.html", rows=rows, username=current_user.username)



            




#收入
@app.route("/user/revenu", methods=["GET", "POST"])
@login_required
def revenu():
    if request.method == "POST":
        # 處理使用者提交的記帳資料
        name = request.form['name']
        category = request.form['category']
        date = request.form['date']
        money = request.form['money']

        # 將資料寫入資料庫，確保只有當前登入的使用者的資料被寫入
        with conn.cursor() as cursor08:
            sql_insert = "INSERT INTO revenu (name, category, date, money, username) VALUES (%s, %s, %s, %s, %s)"
            cursor08.execute(sql_insert, (name, category, date, money, current_user.username))
            conn.commit()

        return redirect(url_for('revenu'))
    else:
        # 讀取當前登入使用者的記帳紀錄
        with conn.cursor() as cursor08:
            sql_select = "SELECT * FROM revenu WHERE username = %s"
            cursor08.execute(sql_select, (current_user.username,))
            rows = cursor08.fetchall()

        return render_template("revenu.html", rows=rows, username=current_user.username)

 






 
 
@app.route("/hello/")
@app.route("/hello/<name>")
def hello_there(name= None):
   return render_template(
     "hello_there.html",
      name=name,
      date=datetime.now()
)
 
@app.route("/api/data")
def get_data():
   return app.send_static_file("data.json")
 
if __name__ == "__main__":
  app.run(debug= True, host="0.0.0.0", port=5000)


  